﻿namespace Practice1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var fibinaccinum = new List<int> { 1,1};
            while (fibinaccinum.Count < 20)
            {
                var last_num = fibinaccinum[fibinaccinum.Count - 1];
                var second_from_last_num = fibinaccinum[fibinaccinum.Count - 2];

                fibinaccinum.Add(last_num + second_from_last_num);
                               
            }
            foreach (var item in fibinaccinum)
                Console.WriteLine(item);
        }
    }
}